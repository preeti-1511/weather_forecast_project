require 'rails_helper'

RSpec.describe Forecast, type: :model do
  describe 'validations' do
    it 'is valid with a valid address' do
      forecast = Forecast.new(address: '123 Main St, New York, NY 10001')
      expect(forecast).to be_valid
    end

    it 'is invalid without an address' do
      forecast = Forecast.new(address: nil)
      expect(forecast).not_to be_valid
      expect(forecast.errors[:address]).to include("can't be blank")
    end

    it 'is invalid with an address shorter than 3 characters' do
      forecast = Forecast.new(address: 'AB')
      expect(forecast).not_to be_valid
      expect(forecast.errors[:address]).to be_present
    end
  end

  describe 'attributes' do
    it 'has all required attributes' do
      forecast = Forecast.new(
        address: '123 Main St',
        current_temp: 72.5,
        high_temp: 80.0,
        low_temp: 65.0,
        description: 'Sunny',
        humidity: 50,
        wind_speed: 10.5,
        cached: false,
        zip_code: '10001'
      )

      expect(forecast.address).to eq('123 Main St')
      expect(forecast.current_temp).to eq(72.5)
      expect(forecast.high_temp).to eq(80.0)
      expect(forecast.low_temp).to eq(65.0)
      expect(forecast.description).to eq('Sunny')
      expect(forecast.humidity).to eq(50)
      expect(forecast.wind_speed).to eq(10.5)
      expect(forecast.cached).to be false
      expect(forecast.zip_code).to eq('10001')
    end

    it 'defaults cached to false' do
      forecast = Forecast.new(address: '123 Main St')
      expect(forecast.cached).to be false
    end
  end
end










