# Forecast model - represents forecast data structure
# This is a value object/struct-like model for organizing forecast data
class Forecast
  include ActiveModel::Model
  include ActiveModel::Attributes

  # Attributes for forecast data
  attribute :address, :string
  attribute :current_temp, :float
  attribute :high_temp, :float
  attribute :low_temp, :float
  attribute :description, :string
  attribute :humidity, :integer
  attribute :wind_speed, :float
  attribute :cached, :boolean, default: false
  attribute :zip_code, :string

  # Validations
  validates :address, presence: true, length: { minimum: 3 }
end










