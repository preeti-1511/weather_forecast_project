# Weather Forecast Application

A Ruby on Rails application that retrieves and displays weather forecast data for a given address. The application implements caching to optimize API calls and provides both web interface and RESTful API endpoints.

## Features

- **Address Input**: Accepts any address as input (web form or API)
- **Weather Forecast**: Retrieves current temperature, high/low temperatures, humidity, wind speed, and weather description
- **Caching**: Implements 30-minute cache based on zip code to reduce API calls
- **Cache Indicator**: Displays visual indicator when results are served from cache
- **RESTful API**: JSON API endpoints for testing with Postman or other API clients
- **Error Handling**: Comprehensive error handling for API failures and invalid addresses

## Requirements

- Ruby 3.0.0 or higher
- Rails 7.0.0 or higher
- SQLite3
- OpenWeatherMap API key (free tier available at https://openweathermap.org/api)

## Installation

### Windows Users
See `INSTALLATION_WINDOWS.md` for detailed Windows installation instructions.

### Quick Setup

1. **Install Ruby and Rails** (if not already installed)
   - Windows: See `INSTALLATION_WINDOWS.md`
   - Mac/Linux: Use rbenv, rvm, or system package manager

2. **Install Dependencies**
   ```bash
   bundle install
   ```

3. **Set Up Environment Variables**
   - Copy `.env.example` to `.env`
   - Add your OpenWeatherMap API key:
     ```
     OPENWEATHER_API_KEY=your_api_key_here
     ```

4. **Start the Server**
   ```bash
   rails server
   ```

5. **Access the Application**
   - Web Interface: `http://localhost:3000`
   - API Base URL: `http://localhost:3000/api/v1`

## API Endpoints

### Quick API Test

**Health Check:**
```
GET http://localhost:3000/api/v1/forecast/health
```

**Get Forecast (GET):**
```
GET http://localhost:3000/api/v1/forecast?address=1600%20Amphitheatre%20Parkway,%20Mountain%20View,%20CA
```

**Get Forecast (POST):**
```
POST http://localhost:3000/api/v1/forecast
Content-Type: application/json

{
  "address": "1600 Amphitheatre Parkway, Mountain View, CA"
}
```

### Postman Testing

1. **Import Collection**: Import `postman_collection.json` into Postman
2. **See Documentation**: Check `API_DOCUMENTATION.md` for complete API docs
3. **Quick Guide**: See `POSTMAN_TESTING.md` for step-by-step testing guide

## Usage

### Web Interface

1. Navigate to `http://localhost:3000`
2. Enter an address in the form
3. Click "Get Forecast"
4. View the weather forecast with cache indicator

### API Usage

See `API_DOCUMENTATION.md` for complete API documentation including:
- Endpoint details
- Request/response formats
- Error handling
- Example requests

## Testing

Run the test suite:
```bash
bundle exec rspec
```

Run specific test files:
```bash
bundle exec rspec spec/models/forecast_spec.rb
bundle exec rspec spec/services/
bundle exec rspec spec/controllers/
```

## Documentation

- **API_DOCUMENTATION.md** - Complete API reference
- **POSTMAN_TESTING.md** - Step-by-step Postman testing guide
- **ARCHITECTURE.md** - Architecture and design patterns
- **INSTALLATION_WINDOWS.md** - Windows installation guide
- **SETUP.md** - General setup instructions
- **QUICK_START.md** - Quick start guide

## Architecture & Design Patterns

### Design Patterns Used

1. **Service Object Pattern** - Business logic encapsulated in services
2. **Value Object Pattern** - Forecast model as a value object
3. **Cache-Aside Pattern** - Caching strategy implementation
4. **Facade Pattern** - ForecastService as a facade

See `ARCHITECTURE.md` for detailed architecture documentation.

## Project Structure

```
app/
├── controllers/
│   ├── api/v1/          # API endpoints
│   └── forecasts_controller.rb
├── models/
│   └── forecast.rb      # Value object
├── services/            # Service objects
│   ├── forecast_service.rb
│   ├── geocoding_service.rb
│   └── weather_api_service.rb
└── views/               # Web interface
```

## Caching Strategy

- **Cache Key**: `forecast:{zip_code}`
- **TTL**: 30 minutes
- **Cache Store**: Memory store (development), Redis recommended for production
- **Cache Indicator**: Visual feedback in web UI and `cached` field in API responses

## API Response Format

### Success Response
```json
{
  "success": true,
  "data": {
    "address": "1600 Amphitheatre Parkway, Mountain View, CA",
    "zip_code": "94043",
    "current_temperature": 72.5,
    "high_temperature": 80.0,
    "low_temperature": 65.0,
    "description": "Clear sky",
    "humidity": 50,
    "wind_speed": 10.5,
    "cached": false,
    "cache_ttl_minutes": 30
  },
  "cached": false,
  "timestamp": "2024-01-15T10:30:00Z"
}
```

### Error Response
```json
{
  "success": false,
  "error": "Address parameter is required",
  "message": "Please provide an address query parameter"
}
```

## Scalability Considerations

For production deployment:
- Use Redis for distributed caching
- Move API calls to background jobs
- Add monitoring and logging
- Use PostgreSQL instead of SQLite
- Implement rate limiting

See `ARCHITECTURE.md` for detailed scalability recommendations.

## License

This project is created as a coding assignment.

## Support

For issues or questions:
- Check the documentation files
- Review `ARCHITECTURE.md` for implementation details
- See `SETUP.md` for installation instructions
- Check `API_DOCUMENTATION.md` for API usage
