require 'rails_helper'

RSpec.describe GeocodingService do
  describe '.geocode' do
    let(:address) { '1600 Amphitheatre Parkway, Mountain View, CA' }
    
    context 'with a valid address' do
      let(:mock_result) do
        double(
          latitude: 37.4224764,
          longitude: -122.0842499,
          postal_code: '94043',
          address_components: [],
          formatted_address: '1600 Amphitheatre Pkwy, Mountain View, CA 94043, USA'
        )
      end

      before do
        allow(Geocoder).to receive(:search).with(address).and_return([mock_result])
      end

      it 'returns success with coordinates and zip code' do
        result = described_class.geocode(address)
        
        expect(result[:success]).to be true
        expect(result[:latitude]).to eq(37.4224764)
        expect(result[:longitude]).to eq(-122.0842499)
        expect(result[:zip_code]).to eq('94043')
      end
    end

    context 'with an invalid address' do
      before do
        allow(Geocoder).to receive(:search).with(address).and_return([])
      end

      it 'returns failure with error message' do
        result = described_class.geocode(address)
        
        expect(result[:success]).to be false
        expect(result[:error]).to include('Address not found')
      end
    end

    context 'when geocoding raises an error' do
      before do
        allow(Geocoder).to receive(:search).and_raise(StandardError.new('Network error'))
      end

      it 'handles the error gracefully' do
        result = described_class.geocode(address)
        
        expect(result[:success]).to be false
        expect(result[:error]).to include('Geocoding error')
      end
    end

    context 'when zip code is in address_components' do
      let(:mock_result) do
        double(
          latitude: 37.4224764,
          longitude: -122.0842499,
          postal_code: nil,
          address_components: [
            { 'types' => ['postal_code'], 'long_name' => '94043' }
          ],
          formatted_address: '1600 Amphitheatre Pkwy, Mountain View, CA'
        )
      end

      before do
        allow(Geocoder).to receive(:search).with(address).and_return([mock_result])
      end

      it 'extracts zip code from address_components' do
        result = described_class.geocode(address)
        
        expect(result[:success]).to be true
        expect(result[:zip_code]).to eq('94043')
      end
    end
  end
end










