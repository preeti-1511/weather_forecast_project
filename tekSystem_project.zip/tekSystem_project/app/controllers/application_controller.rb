class ApplicationController < ActionController::Base
  # Base controller for the application
  # Provides common functionality for all controllers
  
  # Handle API requests with JSON format
#   before_action :set_default_format, if: -> { request.path.start_with?('/api') }
  
#   private
  
#   def set_default_format
#     request.format = :json if request.format.html?
#   end
end






