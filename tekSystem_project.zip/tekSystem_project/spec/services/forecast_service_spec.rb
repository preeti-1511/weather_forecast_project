require 'rails_helper'
require 'webmock/rspec'

RSpec.describe ForecastService do
  describe '.fetch_forecast' do
    let(:address) { '1600 Amphitheatre Parkway, Mountain View, CA' }
    let(:zip_code) { '94043' }
    let(:latitude) { 37.4224764 }
    let(:longitude) { -122.0842499 }

    let(:geocode_result) do
      {
        success: true,
        latitude: latitude,
        longitude: longitude,
        zip_code: zip_code
      }
    end

    let(:weather_result) do
      {
        success: true,
        current_temp: 72.5,
        high_temp: 80.0,
        low_temp: 65.0,
        description: 'Clear sky',
        humidity: 50,
        wind_speed: 10.5
      }
    end

    before do
      allow(GeocodingService).to receive(:geocode).with(address).and_return(geocode_result)
      allow(WeatherApiService).to receive(:fetch_weather).with(latitude, longitude).and_return(weather_result)
      Rails.cache.clear
    end

    context 'when data is not cached' do
      it 'fetches fresh data from API' do
        result = described_class.fetch_forecast(address)
        
        expect(result[:success]).to be true
        expect(result[:cached]).to be false
        expect(result[:data][:current_temp]).to eq(72.5)
        expect(result[:data][:zip_code]).to eq(zip_code)
      end

      it 'caches the data for future requests' do
        described_class.fetch_forecast(address)
        
        cached_data = Rails.cache.read("forecast:#{zip_code}")
        expect(cached_data).not_to be_nil
        expect(cached_data[:current_temp]).to eq(72.5)
      end
    end

    context 'when data is cached' do
      before do
        # Pre-populate cache
        Rails.cache.write(
          "forecast:#{zip_code}",
          {
            address: address,
            zip_code: zip_code,
            current_temp: 70.0,
            high_temp: 75.0,
            low_temp: 60.0,
            description: 'Cached data',
            humidity: 45,
            wind_speed: 8.0,
            cached: false
          },
          expires_in: 30.minutes
        )
      end

      it 'returns cached data' do
        result = described_class.fetch_forecast(address)
        
        expect(result[:success]).to be true
        expect(result[:cached]).to be true
        expect(result[:data][:current_temp]).to eq(70.0)
        expect(result[:data][:cached]).to be true
      end

      it 'does not call weather API when cache exists' do
        expect(WeatherApiService).not_to receive(:fetch_weather)
        
        described_class.fetch_forecast(address)
      end
    end

    context 'when geocoding fails' do
      before do
        allow(GeocodingService).to receive(:geocode).and_return(
          { success: false, error: 'Address not found' }
        )
      end

      it 'returns error without calling weather API' do
        result = described_class.fetch_forecast(address)
        
        expect(result[:success]).to be false
        expect(result[:error]).to include('Address not found')
        expect(WeatherApiService).not_to have_received(:fetch_weather)
      end
    end

    context 'when weather API fails' do
      before do
        allow(WeatherApiService).to receive(:fetch_weather).and_return(
          { success: false, error: 'API error' }
        )
      end

      it 'returns error' do
        result = described_class.fetch_forecast(address)
        
        expect(result[:success]).to be false
        expect(result[:error]).to include('API error')
      end
    end

    context 'cache expiration' do
      it 'respects cache TTL' do
        # Set cache with short TTL for testing
        Rails.cache.write(
          "forecast:#{zip_code}",
          { current_temp: 70.0 },
          expires_in: 1.second
        )
        
        # Wait for cache to expire
        sleep(2)
        
        # Should fetch fresh data
        allow(WeatherApiService).to receive(:fetch_weather).and_return(weather_result)
        result = described_class.fetch_forecast(address)
        
        expect(result[:cached]).to be false
      end
    end
  end
end










