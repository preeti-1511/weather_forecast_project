require 'rails_helper'
require 'webmock/rspec'

RSpec.describe WeatherApiService do
  describe '.fetch_weather' do
    let(:latitude) { 37.4224764 }
    let(:longitude) { -122.0842499 }
    let(:api_key) { 'test_api_key' }
    
    before do
      allow(ENV).to receive(:[]).with('OPENWEATHER_API_KEY').and_return(api_key)
    end

    context 'with successful API response' do
      let(:mock_response) do
        {
          'main' => {
            'temp' => 72.5,
            'temp_max' => 80.0,
            'temp_min' => 65.0,
            'humidity' => 50
          },
          'weather' => [
            { 'description' => 'clear sky' }
          ],
          'wind' => {
            'speed' => 10.5
          }
        }
      end

      before do
        stub_request(:get, /api\.openweathermap\.org/)
          .to_return(
            status: 200,
            body: mock_response.to_json,
            headers: { 'Content-Type' => 'application/json' }
          )
      end

      it 'returns weather data successfully' do
        result = described_class.fetch_weather(latitude, longitude)
        
        expect(result[:success]).to be true
        expect(result[:current_temp]).to eq(72.5)
        expect(result[:high_temp]).to eq(80.0)
        expect(result[:low_temp]).to eq(65.0)
        expect(result[:description]).to eq('Clear sky')
        expect(result[:humidity]).to eq(50)
        expect(result[:wind_speed]).to eq(10.5)
      end
    end

    context 'with API error response' do
      before do
        stub_request(:get, /api\.openweathermap\.org/)
          .to_return(status: 401, body: 'Unauthorized')
      end

      it 'returns error for invalid API key' do
        result = described_class.fetch_weather(latitude, longitude)
        
        expect(result[:success]).to be false
        expect(result[:error]).to include('Invalid API key')
      end
    end

    context 'with network error' do
      before do
        stub_request(:get, /api\.openweathermap\.org/)
          .to_raise(HTTParty::Error.new('Network error'))
      end

      it 'handles network errors gracefully' do
        result = described_class.fetch_weather(latitude, longitude)
        
        expect(result[:success]).to be false
        expect(result[:error]).to include('Network error')
      end
    end

    context 'with 404 error' do
      before do
        stub_request(:get, /api\.openweathermap\.org/)
          .to_return(status: 404, body: 'Not found')
      end

      it 'returns appropriate error message' do
        result = described_class.fetch_weather(latitude, longitude)
        
        expect(result[:success]).to be false
        expect(result[:error]).to include('Weather data not found')
      end
    end

    context 'with 429 rate limit error' do
      before do
        stub_request(:get, /api\.openweathermap\.org/)
          .to_return(status: 429, body: 'Too many requests')
      end

      it 'returns rate limit error message' do
        result = described_class.fetch_weather(latitude, longitude)
        
        expect(result[:success]).to be false
        expect(result[:error]).to include('rate limit')
      end
    end
  end
end










