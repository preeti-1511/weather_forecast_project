# Postman Testing Guide

## Quick Start

### Step 1: Import Postman Collection

1. Open Postman
2. Click **Import** button
3. Select the `postman_collection.json` file from the project root
4. The collection will be imported with all pre-configured requests

### Step 2: Start the Rails Server

```powershell
# After installing Ruby and Rails
rails server
```

The server will start on `http://localhost:3000`

### Step 3: Test the API

Use the imported requests or create new ones using the examples below.

---

## API Endpoints

### 1. Health Check

**Quick Test:** Verify the API is running

- **Method:** GET
- **URL:** `http://localhost:3000/api/v1/forecast/health`
- **Expected Response:** 200 OK with health status

---

### 2. Get Forecast (GET Request)

**Method:** GET  
**URL:** `http://localhost:3000/api/v1/forecast`

**Query Parameters:**
- `address` (required): The address to get forecast for

**Example:**
```
GET http://localhost:3000/api/v1/forecast?address=1600%20Amphitheatre%20Parkway,%20Mountain%20View,%20CA
```

**Postman Setup:**
1. Create new GET request
2. URL: `http://localhost:3000/api/v1/forecast`
3. Go to **Params** tab
4. Add parameter:
   - Key: `address`
   - Value: `1600 Amphitheatre Parkway, Mountain View, CA`

**Expected Success Response:**
```json
{
  "success": true,
  "data": {
    "address": "1600 Amphitheatre Parkway, Mountain View, CA",
    "zip_code": "94043",
    "current_temperature": 72.5,
    "high_temperature": 80.0,
    "low_temperature": 65.0,
    "description": "Clear sky",
    "humidity": 50,
    "wind_speed": 10.5,
    "cached": false,
    "cache_ttl_minutes": 30
  },
  "cached": false,
  "timestamp": "2024-01-15T10:30:00Z"
}
```

---

### 3. Create Forecast (POST Request)

**Method:** POST  
**URL:** `http://localhost:3000/api/v1/forecast`

**Headers:**
- `Content-Type: application/json`

**Body (JSON):**
```json
{
  "address": "1600 Amphitheatre Parkway, Mountain View, CA"
}
```

**Postman Setup:**
1. Create new POST request
2. URL: `http://localhost:3000/api/v1/forecast`
3. Go to **Headers** tab
4. Add header:
   - Key: `Content-Type`
   - Value: `application/json`
5. Go to **Body** tab
6. Select **raw** and **JSON** format
7. Paste the JSON body above

**Expected Success Response:**
```json
{
  "success": true,
  "data": {
    "address": "1600 Amphitheatre Parkway, Mountain View, CA",
    "zip_code": "94043",
    "current_temperature": 72.5,
    "high_temperature": 80.0,
    "low_temperature": 65.0,
    "description": "Clear sky",
    "humidity": 50,
    "wind_speed": 10.5,
    "cached": false,
    "cache_ttl_minutes": 30
  },
  "cached": false,
  "timestamp": "2024-01-15T10:30:00Z"
}
```

---

## Testing Scenarios

### Test 1: Valid Address
```
GET /api/v1/forecast?address=New York, NY 10001
```
**Expected:** Success with forecast data

### Test 2: Missing Address Parameter
```
GET /api/v1/forecast
```
**Expected:** 400 Bad Request with error message

### Test 3: Invalid Address
```
GET /api/v1/forecast?address=InvalidAddress12345
```
**Expected:** 422 Unprocessable Entity with error message

### Test 4: Caching Behavior
1. Make first request: `GET /api/v1/forecast?address=New York, NY 10001`
   - Check `cached: false`
2. Make same request again immediately
   - Check `cached: true`

### Test 5: POST Request
```
POST /api/v1/forecast
Body: { "address": "Los Angeles, CA 90001" }
```
**Expected:** 201 Created with forecast data

---

## Postman Collection Variables

You can set up environment variables in Postman:

1. Create a new Environment
2. Add variables:
   - `base_url`: `http://localhost:3000/api/v1`
   - `address`: `1600 Amphitheatre Parkway, Mountain View, CA`

3. Use in requests:
   - URL: `{{base_url}}/forecast?address={{address}}`

---

## Response Codes

| Code | Meaning |
|------|---------|
| 200 | Success (GET) |
| 201 | Created (POST) |
| 400 | Bad Request - Missing/invalid parameters |
| 422 | Unprocessable Entity - Address not found |
| 500 | Internal Server Error |

---

## Troubleshooting

### Issue: "Connection refused"
- Make sure Rails server is running: `rails server`
- Check the port (default: 3000)

### Issue: "404 Not Found"
- Verify the URL is correct: `/api/v1/forecast`
- Check routes: `rails routes | grep api`

### Issue: "422 Unprocessable Entity"
- Check if `.env` file has `OPENWEATHER_API_KEY`
- Verify the API key is valid
- Check internet connection

### Issue: "500 Internal Server Error"
- Check Rails server logs
- Verify all dependencies are installed: `bundle install`

---

## Example cURL Commands

If you prefer command line testing:

```bash
# Health Check
curl http://localhost:3000/api/v1/forecast/health

# GET Request
curl "http://localhost:3000/api/v1/forecast?address=New%20York,%20NY%2010001"

# POST Request
curl -X POST http://localhost:3000/api/v1/forecast \
  -H "Content-Type: application/json" \
  -d '{"address":"New York, NY 10001"}'
```

---

## Next Steps

1. Import the Postman collection
2. Start the Rails server
3. Test the health endpoint first
4. Test GET and POST requests
5. Verify caching behavior
6. Test error scenarios

For detailed API documentation, see `API_DOCUMENTATION.md`


