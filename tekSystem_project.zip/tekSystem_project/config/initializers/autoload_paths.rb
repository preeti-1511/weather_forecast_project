# Ensure services directory is autoloaded
Rails.application.config.autoload_paths += %W(#{Rails.root}/app/services)










