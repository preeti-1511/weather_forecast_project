# Ruby and Rails Installation Guide for Windows

## Option 1: RubyInstaller (Recommended for Windows)

### Step 1: Install Ruby

1. **Download RubyInstaller**
   - Visit: https://rubyinstaller.org/downloads/
   - Download **Ruby+Devkit 3.0.x** (x64) - matches the `.ruby-version` file
   - Choose the version that matches: **Ruby 3.0.0** or higher

2. **Run the Installer**
   - Run the downloaded `.exe` file
   - ✅ Check "Add Ruby executables to your PATH"
   - ✅ Check "Associate .rb and .rbw files with this Ruby installation"
   - Click "Install"

3. **Complete the Devkit Setup**
   - After installation, a command prompt will open
   - Press Enter to install MSYS2 and MINGW development toolchain
   - Wait for the installation to complete (this may take a few minutes)

4. **Verify Installation**
   ```powershell
   ruby --version
   ```
   Should show: `ruby 3.0.x` or higher

### Step 2: Install Rails

1. **Install Bundler** (Ruby's package manager)
   ```powershell
   gem install bundler
   ```

2. **Install Rails**
   ```powershell
   gem install rails
   ```

3. **Verify Installation**
   ```powershell
   rails --version
   ```
   Should show: `Rails 7.0.x` or higher

### Step 3: Install Project Dependencies

1. **Navigate to Project Directory**
   ```powershell
   cd "C:\Users\Asus\Desktop\tekSystem Assignment"
   ```

2. **Install Gems**
   ```powershell
   bundle install
   ```

---

## Option 2: Using WSL (Windows Subsystem for Linux)

If you prefer a Linux-like environment:

### Step 1: Install WSL

1. Open PowerShell as Administrator
2. Run:
   ```powershell
   wsl --install
   ```
3. Restart your computer when prompted

### Step 2: Install Ruby in WSL

1. Open Ubuntu (or your Linux distribution)
2. Update packages:
   ```bash
   sudo apt update
   sudo apt upgrade
   ```

3. Install Ruby using rbenv (recommended):
   ```bash
   # Install dependencies
   sudo apt install -y git curl libssl-dev libreadline-dev zlib1g-dev autoconf bison build-essential libyaml-dev libreadline-dev libncurses5-dev libffi-dev libgdbm-dev

   # Install rbenv
   curl -fsSL https://github.com/rbenv/rbenv-installer/raw/HEAD/bin/rbenv-installer | bash

   # Add to PATH
   echo 'export PATH="$HOME/.rbenv/bin:$PATH"' >> ~/.bashrc
   echo 'eval "$(rbenv init -)"' >> ~/.bashrc
   source ~/.bashrc

   # Install Ruby 3.0.0
   rbenv install 3.0.0
   rbenv global 3.0.0

   # Verify
   ruby --version
   ```

4. Install Rails:
   ```bash
   gem install bundler rails
   rails --version
   ```

### Step 3: Access Project in WSL

```bash
cd /mnt/c/Users/Asus/Desktop/tekSystem\ Assignment
bundle install
```

---

## Quick Installation Commands (After Ruby is Installed)

Once Ruby is installed, run these commands in PowerShell:

```powershell
# Install Bundler
gem install bundler

# Install Rails
gem install rails

# Navigate to project
cd "C:\Users\Asus\Desktop\tekSystem Assignment"

# Install project dependencies
bundle install

# Set up environment (create .env file)
Copy-Item .env.example .env
# Then edit .env and add your OpenWeatherMap API key

# Create database (if needed)
rails db:create

# Start the server
rails server
```

---

## Troubleshooting

### Issue: "gem install" fails with SSL errors
**Solution:**
```powershell
gem sources --remove https://rubygems.org/
gem sources --add https://rubygems.org/
gem install bundler
```

### Issue: "bundle install" fails
**Solution:**
- Make sure you have the correct Ruby version (3.0.0+)
- Try: `gem update --system`
- Then: `bundle install`

### Issue: "rails server" fails
**Solution:**
- Make sure all dependencies are installed: `bundle install`
- Check for missing gems: `bundle check`
- Try: `bundle exec rails server`

### Issue: Port 3000 already in use
**Solution:**
```powershell
# Use a different port
rails server -p 3001
```

---

## Verification Checklist

After installation, verify everything works:

```powershell
# 1. Check Ruby version
ruby --version
# Should show: ruby 3.0.x

# 2. Check Rails version
rails --version
# Should show: Rails 7.0.x

# 3. Check Bundler
bundle --version
# Should show: Bundler version x.x.x

# 4. Install project dependencies
bundle install
# Should complete without errors

# 5. Check Rails can load
rails --help
# Should show Rails commands
```

---

## Next Steps After Installation

1. **Set up environment variables:**
   ```powershell
   # Copy the example file
   Copy-Item .env.example .env
   
   # Edit .env file and add your OpenWeatherMap API key
   # Get a free key at: https://openweathermap.org/api
   ```

2. **Start the application:**
   ```powershell
   rails server
   ```

3. **Open in browser:**
   - Navigate to: `http://localhost:3000`

---

## Alternative: Using Chocolatey (Package Manager)

If you have Chocolatey installed:

```powershell
# Install Ruby
choco install ruby

# Then follow the Rails installation steps above
gem install bundler rails
```

---

## Need Help?

- RubyInstaller Documentation: https://github.com/oneclick/rubyinstaller2/wiki
- Rails Installation Guide: https://guides.rubyonrails.org/getting_started.html
- Project README: See `README.md` for application-specific setup










