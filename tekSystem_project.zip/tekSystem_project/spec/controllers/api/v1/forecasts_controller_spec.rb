require 'rails_helper'

RSpec.describe Api::V1::ForecastsController, type: :controller do
  describe 'GET #show' do
    let(:address) { '1600 Amphitheatre Parkway, Mountain View, CA' }
    let(:valid_forecast_data) do
      {
        success: true,
        data: {
          address: address,
          zip_code: '94043',
          current_temp: 72.5,
          high_temp: 80.0,
          low_temp: 65.0,
          description: 'Clear sky',
          humidity: 50,
          wind_speed: 10.5,
          cached: false
        },
        cached: false
      }
    end

    context 'with valid address parameter' do
      before do
        allow(ForecastService).to receive(:fetch_forecast).with(address).and_return(valid_forecast_data)
      end

      it 'returns successful JSON response' do
        get :show, params: { address: address }, format: :json
        
        expect(response).to have_http_status(:ok)
        json_response = JSON.parse(response.body)
        
        expect(json_response['success']).to be true
        expect(json_response['data']['address']).to eq(address)
        expect(json_response['data']['current_temperature']).to eq(72.5)
        expect(json_response['data']['zip_code']).to eq('94043')
        expect(json_response['cached']).to be false
        expect(json_response['timestamp']).to be_present
      end
    end

    context 'with missing address parameter' do
      it 'returns error response' do
        get :show, format: :json
        
        expect(response).to have_http_status(:bad_request)
        json_response = JSON.parse(response.body)
        
        expect(json_response['success']).to be false
        expect(json_response['error']).to include('Address parameter is required')
      end
    end

    context 'when forecast service fails' do
      before do
        allow(ForecastService).to receive(:fetch_forecast).and_return(
          { success: false, error: 'Address not found' }
        )
      end

      it 'returns error response' do
        get :show, params: { address: address }, format: :json
        
        expect(response).to have_http_status(:unprocessable_entity)
        json_response = JSON.parse(response.body)
        
        expect(json_response['success']).to be false
        expect(json_response['error']).to include('Address not found')
      end
    end

    context 'with cached data' do
      let(:cached_forecast_data) do
        valid_forecast_data.merge(cached: true, data: valid_forecast_data[:data].merge(cached: true))
      end

      before do
        allow(ForecastService).to receive(:fetch_forecast).with(address).and_return(cached_forecast_data)
      end

      it 'indicates data is cached' do
        get :show, params: { address: address }, format: :json
        
        json_response = JSON.parse(response.body)
        expect(json_response['cached']).to be true
        expect(json_response['data']['cached']).to be true
      end
    end
  end

  describe 'POST #create' do
    let(:address) { '1600 Amphitheatre Parkway, Mountain View, CA' }
    let(:valid_forecast_data) do
      {
        success: true,
        data: {
          address: address,
          zip_code: '94043',
          current_temp: 72.5,
          high_temp: 80.0,
          low_temp: 65.0,
          description: 'Clear sky',
          humidity: 50,
          wind_speed: 10.5,
          cached: false
        },
        cached: false
      }
    end

    context 'with valid address in request body' do
      before do
        allow(ForecastService).to receive(:fetch_forecast).with(address).and_return(valid_forecast_data)
      end

      it 'returns successful JSON response' do
        post :create, params: { address: address }, format: :json
        
        expect(response).to have_http_status(:created)
        json_response = JSON.parse(response.body)
        
        expect(json_response['success']).to be true
        expect(json_response['data']['address']).to eq(address)
        expect(json_response['data']['current_temperature']).to eq(72.5)
      end
    end

    context 'with missing address in request body' do
      it 'returns error response' do
        post :create, format: :json
        
        expect(response).to have_http_status(:bad_request)
        json_response = JSON.parse(response.body)
        
        expect(json_response['success']).to be false
        expect(json_response['error']).to include('Address is required')
      end
    end
  end

  describe 'GET #health' do
    it 'returns health check response' do
      get :health, format: :json
      
      expect(response).to have_http_status(:ok)
      json_response = JSON.parse(response.body)
      
      expect(json_response['status']).to eq('healthy')
      expect(json_response['service']).to eq('Weather Forecast API')
      expect(json_response['version']).to eq('1.0.0')
      expect(json_response['timestamp']).to be_present
    end
  end
end


