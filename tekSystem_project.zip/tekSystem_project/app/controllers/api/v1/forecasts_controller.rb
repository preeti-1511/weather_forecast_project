# API::V1::ForecastsController
# RESTful API controller for weather forecast endpoints
# Returns JSON responses suitable for API clients like Postman
class Api::V1::ForecastsController < ApplicationController
  # Skip CSRF token verification for API requests
  skip_before_action :verify_authenticity_token, if: :json_request?
  
  # GET /api/v1/forecast
  # Query parameter: address
  # Example: GET /api/v1/forecast?address=1600+Amphitheatre+Parkway,+Mountain+View,+CA
  def show
    address = params[:address]
    
    # Validate address parameter
    if address.blank?
      render json: {
        success: false,
        error: 'Address parameter is required',
        message: 'Please provide an address query parameter'
      }, status: :bad_request
      return
    end
    
    # Fetch forecast data using the service
    forecast_data = ForecastService.fetch_forecast(address)
    
    if forecast_data[:success]
      # Return successful response with forecast data
      render json: {
        success: true,
        data: {
          address: forecast_data[:data][:address],
          zip_code: forecast_data[:data][:zip_code],
          current_temperature: forecast_data[:data][:current_temp],
          high_temperature: forecast_data[:data][:high_temp],
          low_temperature: forecast_data[:data][:low_temp],
          description: forecast_data[:data][:description],
          humidity: forecast_data[:data][:humidity],
          wind_speed: forecast_data[:data][:wind_speed],
          cached: forecast_data[:cached],
          cache_ttl_minutes: 30
        },
        cached: forecast_data[:cached],
        timestamp: Time.current.iso8601
      }, status: :ok
    else
      # Return error response
      render json: {
        success: false,
        error: forecast_data[:error] || 'Unable to retrieve forecast data',
        message: 'Failed to fetch weather forecast'
      }, status: :unprocessable_entity
    end
  end
  
  # POST /api/v1/forecast
  # Request body: { "address": "1600 Amphitheatre Parkway, Mountain View, CA" }
  def create
    address = forecast_params[:address]
    
    # Validate address parameter
    if address.blank?
      render json: {
        success: false,
        error: 'Address is required',
        message: 'Please provide an address in the request body'
      }, status: :bad_request
      return
    end
    
    # Fetch forecast data using the service
    forecast_data = ForecastService.fetch_forecast(address)
    
    if forecast_data[:success]
      # Return successful response with forecast data
      render json: {
        success: true,
        data: {
          address: forecast_data[:data][:address],
          zip_code: forecast_data[:data][:zip_code],
          current_temperature: forecast_data[:data][:current_temp],
          high_temperature: forecast_data[:data][:high_temp],
          low_temperature: forecast_data[:data][:low_temp],
          description: forecast_data[:data][:description],
          humidity: forecast_data[:data][:humidity],
          wind_speed: forecast_data[:data][:wind_speed],
          cached: forecast_data[:cached],
          cache_ttl_minutes: 30
        },
        cached: forecast_data[:cached],
        timestamp: Time.current.iso8601
      }, status: :created
    else
      # Return error response
      render json: {
        success: false,
        error: forecast_data[:error] || 'Unable to retrieve forecast data',
        message: 'Failed to fetch weather forecast'
      }, status: :unprocessable_entity
    end
  end
  
  # GET /api/v1/forecast/health
  # Health check endpoint
  def health
    render json: {
      status: 'healthy',
      service: 'Weather Forecast API',
      version: '1.0.0',
      timestamp: Time.current.iso8601
    }, status: :ok
  end

  private

  def forecast_params
    params.permit(:address)
  end
  
  def json_request?
    request.format.json?
  end
end


