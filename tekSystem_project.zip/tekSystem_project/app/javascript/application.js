// Entry point for the asset pipeline










