# WeatherApiService - Service Object Pattern
# Handles communication with external weather API (OpenWeatherMap)
# Encapsulates API-specific logic and error handling
class WeatherApiService
  BASE_URL = Figaro.env.base_url
  API_KEY = Figaro.env.openweather_api_key

  # Fetch weather data for given coordinates
  # @param latitude [Float] Latitude coordinate
  # @param longitude [Float] Longitude coordinate
  # @return [Hash] Hash with weather data or error information
  def self.fetch_weather(latitude, longitude)
    new.fetch_weather(latitude, longitude)
  end

  def fetch_weather(latitude, longitude)
    # Build API request URL
    url = build_url(latitude, longitude)
    
    # Make HTTP request
    response = HTTParty.get(url)
    
    if response.success?
      parse_response(response)
    else
      handle_error(response)
    end
  rescue HTTParty::Error => e
    { success: false, error: "Network error: #{e.message}" }
  rescue StandardError => e
    { success: false, error: "Unexpected error: #{e.message}" }
  end

  private

  # Build the API request URL with parameters
  def build_url(latitude, longitude)
    params = {
      'lat' => latitude.to_s,
      'lon' => longitude.to_s,
      'appid' => API_KEY,
      'units' => 'imperial' # Use Fahrenheit for temperature
    }
    
    query_string = URI.encode_www_form(params)
    "#{BASE_URL}?#{query_string}"
  end

  # Parse successful API response
  def parse_response(response)
    data = response.parsed_response
    
    {
      success: true,
      current_temp: data['main']['temp'].to_f,
      high_temp: data['main']['temp_max'].to_f,
      low_temp: data['main']['temp_min'].to_f,
      description: data['weather'].first['description'].capitalize,
      humidity: data['main']['humidity'].to_i,
      wind_speed: data['wind']['speed'].to_f
    }
  end

  # Handle API error responses
  def handle_error(response)
    error_message = case response.code
                    when 401
                      'Invalid API key. Please configure OPENWEATHER_API_KEY.'
                    when 404
                      'Weather data not found for this location.'
                    when 429
                      'API rate limit exceeded. Please try again later.'
                    else
                      "API error: #{response.code} - #{response.message}"
                    end
    
    { success: false, error: error_message }
  end
end

