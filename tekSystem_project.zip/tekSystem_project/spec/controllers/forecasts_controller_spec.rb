require 'rails_helper'

RSpec.describe ForecastsController, type: :controller do
  describe 'GET #new' do
    it 'renders the new template' do
      get :new
      expect(response).to render_template(:new)
    end

    it 'assigns a new forecast' do
      get :new
      expect(assigns(:forecast)).to be_a_new(Forecast)
    end
  end

  describe 'POST #create' do
    let(:address) { '1600 Amphitheatre Parkway, Mountain View, CA' }
    let(:valid_forecast_data) do
      {
        success: true,
        data: {
          address: address,
          zip_code: '94043',
          current_temp: 72.5,
          high_temp: 80.0,
          low_temp: 65.0,
          description: 'Clear sky',
          humidity: 50,
          wind_speed: 10.5,
          cached: false
        },
        cached: false
      }
    end

    context 'with valid address' do
      before do
        allow(ForecastService).to receive(:fetch_forecast).with(address).and_return(valid_forecast_data)
      end

      it 'redirects to show page on success' do
        post :create, params: { forecast: { address: address } }
        expect(response).to redirect_to(forecast_path(assigns(:forecast)))
      end

      it 'sets flash notice on success' do
        post :create, params: { forecast: { address: address } }
        expect(flash[:notice]).to eq('Forecast retrieved successfully!')
      end

      it 'assigns forecast data' do
        post :create, params: { forecast: { address: address } }
        forecast = assigns(:forecast)
        expect(forecast.current_temp).to eq(72.5)
        expect(forecast.zip_code).to eq('94043')
      end
    end

    context 'with cached data' do
      let(:cached_forecast_data) do
        valid_forecast_data.merge(
          cached: true,
          data: valid_forecast_data[:data].merge(cached: true)
        )
      end

      before do
        allow(ForecastService).to receive(:fetch_forecast).with(address).and_return(cached_forecast_data)
      end

      it 'marks forecast as cached' do
        post :create, params: { forecast: { address: address } }
        expect(assigns(:forecast).cached).to be true
      end
    end

    context 'with invalid address' do
      before do
        allow(ForecastService).to receive(:fetch_forecast).and_return(
          { success: false, error: 'Address not found' }
        )
      end

      it 'renders new template with error' do
        post :create, params: { forecast: { address: address } }
        expect(response).to render_template(:new)
      end

      it 'sets flash alert with error message' do
        post :create, params: { forecast: { address: address } }
        expect(flash[:alert]).to include('Address not found')
      end
    end

    context 'with invalid forecast params' do
      it 'renders new template when address is blank' do
        post :create, params: { forecast: { address: '' } }
        expect(response).to render_template(:new)
      end
    end
  end

  describe 'GET #show' do
    let(:forecast_params) do
      {
        address: '1600 Amphitheatre Parkway, Mountain View, CA',
        current_temp: '72.5',
        high_temp: '80.0',
        low_temp: '65.0',
        description: 'Clear sky',
        humidity: '50',
        wind_speed: '10.5',
        cached: 'false',
        zip_code: '94043'
      }
    end

    it 'renders the show template' do
      get :show, params: forecast_params
      expect(response).to render_template(:show)
    end

    it 'assigns forecast with correct attributes' do
      get :show, params: forecast_params
      forecast = assigns(:forecast)
      expect(forecast.address).to eq(forecast_params[:address])
      expect(forecast.current_temp).to eq(72.5)
      expect(forecast.cached).to be false
    end

    it 'handles cached flag correctly' do
      get :show, params: forecast_params.merge(cached: 'true')
      expect(assigns(:forecast).cached).to be true
    end
  end
end










