# Setup Instructions

## Prerequisites

**⚠️ IMPORTANT: Install Ruby and Rails First!**

- **Windows Users**: See `INSTALLATION_WINDOWS.md` for detailed Windows installation instructions
- **Mac/Linux Users**: Use rbenv, rvm, or system package manager

## Quick Start

1. **Install Ruby** (if not already installed)
   - **Windows**: See `INSTALLATION_WINDOWS.md` for RubyInstaller instructions
   - **Mac/Linux**: Visit https://www.ruby-lang.org/en/downloads/
   - Or use a version manager like rbenv or rvm

2. **Install Bundler**
   ```bash
   gem install bundler
   ```

3. **Install Dependencies**
   ```bash
   bundle install
   ```

4. **Set Up Environment Variables**
   - Copy `.env.example` to `.env`
   - Add your OpenWeatherMap API key:
     ```
     OPENWEATHER_API_KEY=your_actual_api_key_here
     ```
   - Get a free API key at: https://openweathermap.org/api

5. **Set Up Database** (if using ActiveRecord features)
   ```bash
   rails db:create
   rails db:migrate
   ```

6. **Start the Server**
   ```bash
   rails server
   ```

7. **Open in Browser**
   - Navigate to `http://localhost:3000`

## Running Tests

```bash
# Run all tests
bundle exec rspec

# Run specific test file
bundle exec rspec spec/models/forecast_spec.rb

# Run with documentation format
bundle exec rspec --format documentation
```

## Troubleshooting

### Issue: "rails command not found"
- Make sure Ruby and Rails are installed
- Try: `gem install rails`
- Verify with: `rails --version`

### Issue: "Bundle install fails"
- Make sure you have the correct Ruby version (3.0.0+)
- Check: `ruby --version`

### Issue: "API key error"
- Make sure `.env` file exists in the root directory
- Verify the API key is correct
- Check that the key is active on OpenWeatherMap

### Issue: "Geocoding fails"
- The app uses OpenStreetMap Nominatim (free service)
- Rate limits: 1 request per second
- If issues persist, check your internet connection

