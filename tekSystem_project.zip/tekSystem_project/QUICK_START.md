# Quick Start Guide

## For Windows Users

### Step 1: Install Ruby and Rails

**Option A: RubyInstaller (Easiest)**
1. Download from: https://rubyinstaller.org/downloads/
2. Install **Ruby+Devkit 3.0.x (x64)**
3. After installation, run in PowerShell:
   ```powershell
   gem install bundler rails
   ```

**Option B: Use the Detailed Guide**
- See `INSTALLATION_WINDOWS.md` for complete instructions

### Step 2: Run Setup Script

```powershell
# Navigate to project directory
cd "C:\Users\Asus\Desktop\tekSystem Assignment"

# Run the setup script
.\setup.ps1
```

### Step 3: Configure API Key

1. Open `.env` file in a text editor
2. Add your OpenWeatherMap API key:
   ```
   OPENWEATHER_API_KEY=your_api_key_here
   ```
3. Get a free API key at: https://openweathermap.org/api

### Step 4: Start the Application

```powershell
rails server
```

### Step 5: Open in Browser

Navigate to: **http://localhost:3000**

---

## Manual Setup (If Script Doesn't Work)

```powershell
# 1. Install dependencies
bundle install

# 2. Create .env file (if it doesn't exist)
Copy-Item .env.example .env

# 3. Edit .env and add your API key

# 4. Start server
rails server
```

---

## Verify Installation

Run these commands to verify everything is set up:

```powershell
# Check Ruby
ruby --version
# Should show: ruby 3.0.x

# Check Rails
rails --version
# Should show: Rails 7.0.x

# Check Bundler
bundle --version
# Should show: Bundler version x.x.x
```

---

## Troubleshooting

**"ruby command not found"**
- Ruby is not installed or not in PATH
- See `INSTALLATION_WINDOWS.md`

**"bundle install fails"**
- Make sure Ruby 3.0.0+ is installed
- Try: `gem update --system` then `bundle install`

**"rails server fails"**
- Make sure all dependencies are installed: `bundle install`
- Check `.env` file exists and has API key

**Port 3000 already in use**
```powershell
rails server -p 3001
```

---

## Need More Help?

- **Windows Installation**: See `INSTALLATION_WINDOWS.md`
- **General Setup**: See `SETUP.md`
- **Architecture**: See `ARCHITECTURE.md`
- **Project Overview**: See `README.md`










