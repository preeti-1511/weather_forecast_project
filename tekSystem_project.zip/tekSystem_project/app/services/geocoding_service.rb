# GeocodingService - Service Object Pattern
# Handles address geocoding to convert addresses to coordinates and zip codes
# Uses Geocoder gem for geocoding functionality
class GeocodingService
  # Geocode an address to get coordinates and zip code
  # @param address [String] The address to geocode
  # @return [Hash] Hash with :success, :latitude, :longitude, :zip_code, or :error
  def self.geocode(address)
    new(address).geocode
  end

  def initialize(address)
    @address = address
  end

  def geocode
    # Use Geocoder gem to geocode the address
    results = Geocoder.search(@address)
    
    if results.empty?
      return { success: false, error: 'Address not found. Please check the address and try again.' }
    end

    result = results.first
    
    # Extract zip code from address components
    zip_code = extract_zip_code(result)
    
    unless zip_code
      return { success: false, error: 'Unable to determine zip code from address.' }
    end

    {
      success: true,
      latitude: result.latitude,
      longitude: result.longitude,
      zip_code: zip_code
    }
  rescue StandardError => e
    { success: false, error: "Geocoding error: #{e.message}" }
  end

  private

  # Extract zip code from geocoding result
  # Tries multiple fields to find zip code
  def extract_zip_code(result)
    # Try postal_code first (most common)
    return result.postal_code if result.postal_code.present?
    
    # Try address_components
    if result.respond_to?(:address_components)
      postal_component = result.address_components.find do |component|
        component['types']&.include?('postal_code')
      end
      return postal_component['long_name'] if postal_component
    end
    
    # Fallback: try to extract from formatted address
    if result.respond_to?(:formatted_address)
      zip_match = result.formatted_address.match(/\b\d{5}(?:-\d{4})?\b/)
      return zip_match[0] if zip_match
    end
    
    nil
  end
end










