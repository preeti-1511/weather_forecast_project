# Weather Forecast API Documentation

## Base URL

```
http://localhost:3000/api/v1
```

## Endpoints

### 1. Get Forecast (GET)

Retrieve weather forecast for a given address.

**Endpoint:** `GET /api/v1/forecast`

**Query Parameters:**
- `address` (required) - The address to get forecast for

**Example Request:**
```
GET http://localhost:3000/api/v1/forecast?address=1600%20Amphitheatre%20Parkway,%20Mountain%20View,%20CA
```

**Success Response (200 OK):**
```json
{
  "success": true,
  "data": {
    "address": "1600 Amphitheatre Parkway, Mountain View, CA",
    "zip_code": "94043",
    "current_temperature": 72.5,
    "high_temperature": 80.0,
    "low_temperature": 65.0,
    "description": "Clear sky",
    "humidity": 50,
    "wind_speed": 10.5,
    "cached": false,
    "cache_ttl_minutes": 30
  },
  "cached": false,
  "timestamp": "2024-01-15T10:30:00Z"
}
```

**Error Response (400 Bad Request):**
```json
{
  "success": false,
  "error": "Address parameter is required",
  "message": "Please provide an address query parameter"
}
```

**Error Response (422 Unprocessable Entity):**
```json
{
  "success": false,
  "error": "Address not found. Please check the address and try again.",
  "message": "Failed to fetch weather forecast"
}
```

---

### 2. Create Forecast (POST)

Retrieve weather forecast for a given address using POST request.

**Endpoint:** `POST /api/v1/forecast`

**Headers:**
```
Content-Type: application/json
```

**Request Body:**
```json
{
  "address": "1600 Amphitheatre Parkway, Mountain View, CA"
}
```

**Success Response (201 Created):**
```json
{
  "success": true,
  "data": {
    "address": "1600 Amphitheatre Parkway, Mountain View, CA",
    "zip_code": "94043",
    "current_temperature": 72.5,
    "high_temperature": 80.0,
    "low_temperature": 65.0,
    "description": "Clear sky",
    "humidity": 50,
    "wind_speed": 10.5,
    "cached": false,
    "cache_ttl_minutes": 30
  },
  "cached": false,
  "timestamp": "2024-01-15T10:30:00Z"
}
```

**Error Response (400 Bad Request):**
```json
{
  "success": false,
  "error": "Address is required",
  "message": "Please provide an address in the request body"
}
```

---

### 3. Health Check

Check if the API is running and healthy.

**Endpoint:** `GET /api/v1/forecast/health`

**Example Request:**
```
GET http://localhost:3000/api/v1/forecast/health
```

**Success Response (200 OK):**
```json
{
  "status": "healthy",
  "service": "Weather Forecast API",
  "version": "1.0.0",
  "timestamp": "2024-01-15T10:30:00Z"
}
```

---

## Response Fields

### Success Response Fields

| Field | Type | Description |
|-------|------|-------------|
| `success` | boolean | Indicates if the request was successful |
| `data` | object | Forecast data object |
| `data.address` | string | The input address |
| `data.zip_code` | string | Zip code extracted from address |
| `data.current_temperature` | float | Current temperature in Fahrenheit |
| `data.high_temperature` | float | High temperature for the day |
| `data.low_temperature` | float | Low temperature for the day |
| `data.description` | string | Weather condition description |
| `data.humidity` | integer | Humidity percentage |
| `data.wind_speed` | float | Wind speed in mph |
| `data.cached` | boolean | Whether data was served from cache |
| `data.cache_ttl_minutes` | integer | Cache time-to-live in minutes (30) |
| `cached` | boolean | Whether response was from cache |
| `timestamp` | string | ISO 8601 timestamp of the response |

### Error Response Fields

| Field | Type | Description |
|-------|------|-------------|
| `success` | boolean | Always `false` for errors |
| `error` | string | Error message describing what went wrong |
| `message` | string | User-friendly error message |

---

## Caching

- Forecasts are cached for **30 minutes** based on zip code
- The `cached` field indicates if the response came from cache
- Subsequent requests for the same zip code within 30 minutes will return cached data
- Cache is automatically refreshed after 30 minutes

---

## Postman Collection

### Import into Postman

1. Create a new collection in Postman
2. Add the following requests:

#### Request 1: Get Forecast (GET)
- **Method:** GET
- **URL:** `http://localhost:3000/api/v1/forecast?address={{address}}`
- **Params:**
  - Key: `address`
  - Value: `1600 Amphitheatre Parkway, Mountain View, CA`

#### Request 2: Create Forecast (POST)
- **Method:** POST
- **URL:** `http://localhost:3000/api/v1/forecast`
- **Headers:**
  - Key: `Content-Type`
  - Value: `application/json`
- **Body (raw JSON):**
```json
{
  "address": "1600 Amphitheatre Parkway, Mountain View, CA"
}
```

#### Request 3: Health Check
- **Method:** GET
- **URL:** `http://localhost:3000/api/v1/forecast/health`

---

## Example cURL Commands

### GET Request
```bash
curl -X GET "http://localhost:3000/api/v1/forecast?address=1600%20Amphitheatre%20Parkway,%20Mountain%20View,%20CA"
```

### POST Request
```bash
curl -X POST "http://localhost:3000/api/v1/forecast" \
  -H "Content-Type: application/json" \
  -d '{"address":"1600 Amphitheatre Parkway, Mountain View, CA"}'
```

### Health Check
```bash
curl -X GET "http://localhost:3000/api/v1/forecast/health"
```

---

## Error Codes

| Status Code | Description |
|------------|-------------|
| 200 | Success (GET request) |
| 201 | Created (POST request) |
| 400 | Bad Request - Missing or invalid parameters |
| 422 | Unprocessable Entity - Address not found or API error |
| 500 | Internal Server Error |

---

## Testing Tips

1. **Test with different addresses:**
   - Valid US address: `1600 Amphitheatre Parkway, Mountain View, CA`
   - Valid address with zip: `New York, NY 10001`
   - Invalid address: `Invalid Address 12345`

2. **Test caching:**
   - Make the same request twice within 30 minutes
   - First request: `cached: false`
   - Second request: `cached: true`

3. **Test error handling:**
   - Missing address parameter
   - Invalid address
   - Network errors (if API is down)

---

## Environment Variables

Make sure to set up your `.env` file with:
```
OPENWEATHER_API_KEY=your_api_key_here
```

Get a free API key at: https://openweathermap.org/api

---

## Rate Limits

- **OpenWeatherMap API:** 60 calls/minute (free tier)
- **Geocoding (Nominatim):** 1 request/second
- **Application Cache:** Reduces API calls by caching for 30 minutes

---

## Support

For issues or questions:
- Check the main README.md
- Review ARCHITECTURE.md for implementation details
- See SETUP.md for installation instructions


