# PowerShell Setup Script for Weather Forecast Application
# Run this script after installing Ruby and Rails

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "Weather Forecast App - Setup Script" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

# Check if Ruby is installed
Write-Host "Checking Ruby installation..." -ForegroundColor Yellow
try {
    $rubyVersion = ruby --version 2>&1
    Write-Host "✓ Ruby found: $rubyVersion" -ForegroundColor Green
} catch {
    Write-Host "✗ Ruby is not installed!" -ForegroundColor Red
    Write-Host "Please install Ruby first. See INSTALLATION_WINDOWS.md" -ForegroundColor Yellow
    exit 1
}

# Check if Rails is installed
Write-Host "Checking Rails installation..." -ForegroundColor Yellow
try {
    $railsVersion = rails --version 2>&1
    Write-Host "✓ Rails found: $railsVersion" -ForegroundColor Green
} catch {
    Write-Host "✗ Rails is not installed!" -ForegroundColor Red
    Write-Host "Installing Rails..." -ForegroundColor Yellow
    gem install rails
}

# Check if Bundler is installed
Write-Host "Checking Bundler installation..." -ForegroundColor Yellow
try {
    $bundleVersion = bundle --version 2>&1
    Write-Host "✓ Bundler found: $bundleVersion" -ForegroundColor Green
} catch {
    Write-Host "✗ Bundler is not installed!" -ForegroundColor Red
    Write-Host "Installing Bundler..." -ForegroundColor Yellow
    gem install bundler
}

# Install project dependencies
Write-Host ""
Write-Host "Installing project dependencies..." -ForegroundColor Yellow
bundle install

if ($LASTEXITCODE -eq 0) {
    Write-Host "✓ Dependencies installed successfully!" -ForegroundColor Green
} else {
    Write-Host "✗ Failed to install dependencies!" -ForegroundColor Red
    exit 1
}

# Check for .env file
Write-Host ""
Write-Host "Checking environment configuration..." -ForegroundColor Yellow
if (Test-Path ".env") {
    Write-Host "✓ .env file exists" -ForegroundColor Green
} else {
    Write-Host "⚠ .env file not found!" -ForegroundColor Yellow
    if (Test-Path ".env.example") {
        Write-Host "Creating .env from .env.example..." -ForegroundColor Yellow
        Copy-Item ".env.example" ".env"
        Write-Host "✓ .env file created" -ForegroundColor Green
        Write-Host ""
        Write-Host "⚠ IMPORTANT: Edit .env file and add your OpenWeatherMap API key!" -ForegroundColor Yellow
        Write-Host "Get a free API key at: https://openweathermap.org/api" -ForegroundColor Cyan
    } else {
        Write-Host "✗ .env.example not found!" -ForegroundColor Red
    }
}

# Summary
Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "Setup Complete!" -ForegroundColor Green
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "Next steps:" -ForegroundColor Yellow
Write-Host "1. Edit .env file and add your OpenWeatherMap API key" -ForegroundColor White
Write-Host "2. Run: rails server" -ForegroundColor White
Write-Host "3. Open: http://localhost:3000" -ForegroundColor White
Write-Host ""










