class ForecastsController < ApplicationController
  # Controller responsible for handling forecast requests
  # Implements caching strategy with 30-minute TTL based on zip code
  
  def new
    # Display the form to input an address
    @forecast = Forecast.new
  end

  def create
    # Process the address input and fetch forecast
    @forecast = Forecast.new(forecast_params)
    
    if @forecast.valid?
      # Attempt to fetch forecast data (with caching)
      forecast_data = ForecastService.fetch_forecast(@forecast.address)
      
      if forecast_data[:success]
        @forecast.assign_attributes(forecast_data[:data])
        @forecast.cached = forecast_data[:cached]
        redirect_to forecast_result_path(
          address: @forecast.address,
          current_temp: @forecast.current_temp,
          high_temp: @forecast.high_temp,
          low_temp: @forecast.low_temp,
          description: @forecast.description,
          humidity: @forecast.humidity,
          wind_speed: @forecast.wind_speed,
          cached: @forecast.cached,
          zip_code: @forecast.zip_code
        ), notice: 'Forecast retrieved successfully!'
      else
        flash.now[:alert] = forecast_data[:error] || 'Unable to retrieve forecast data.'
        render :new, status: :unprocessable_entity
      end
    else
      render :new, status: :unprocessable_entity
    end
  end

  def show
    # Display the forecast results
    @forecast = Forecast.new(
      address: params[:address],
      current_temp: params[:current_temp],
      high_temp: params[:high_temp],
      low_temp: params[:low_temp],
      description: params[:description],
      humidity: params[:humidity],
      wind_speed: params[:wind_speed],
      cached: params[:cached] == 'true',
      zip_code: params[:zip_code]
    )
  end

  private

  def forecast_params
    params.require(:forecast).permit(:address)
  end
end

