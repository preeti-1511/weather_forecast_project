# ForecastService - Service Object Pattern
# Encapsulates the business logic for fetching and caching weather forecasts
# Implements caching strategy with 30-minute TTL based on zip code
class ForecastService
  CACHE_TTL = 30.minutes

  # Main entry point for fetching forecast data
  # @param address [String] The address to get forecast for
  # @return [Hash] Hash with :success, :data, :cached, and optionally :error keys
  def self.fetch_forecast(address)
    new(address).fetch_forecast
  end

  def initialize(address)
    @address = address
  end

  def fetch_forecast
    # Step 1: Geocode the address to get zip code
    geocode_result = GeocodingService.geocode(@address)
    
    unless geocode_result[:success]
      return { success: false, error: geocode_result[:error] }
    end

    zip_code = geocode_result[:zip_code]
    cache_key = "forecast:#{zip_code}"

    # Step 2: Check cache first
    cached_data = Rails.cache.read(cache_key)
    if cached_data
      return {
        success: true,
        data: cached_data.merge(cached: true),
        cached: true
      }
    end

    # Step 3: Fetch fresh data from API
    weather_result = WeatherApiService.fetch_weather(
      geocode_result[:latitude],
      geocode_result[:longitude]
    )

    unless weather_result[:success]
      return { success: false, error: weather_result[:error] }
    end

    # Step 4: Prepare forecast data
    forecast_data = {
      address: @address,
      zip_code: zip_code,
      current_temp: weather_result[:current_temp],
      high_temp: weather_result[:high_temp],
      low_temp: weather_result[:low_temp],
      description: weather_result[:description],
      humidity: weather_result[:humidity],
      wind_speed: weather_result[:wind_speed],
      cached: false
    }

    # Step 5: Cache the data for 30 minutes
    Rails.cache.write(cache_key, forecast_data, expires_in: CACHE_TTL)

    {
      success: true,
      data: forecast_data,
      cached: false
    }
  end
end










