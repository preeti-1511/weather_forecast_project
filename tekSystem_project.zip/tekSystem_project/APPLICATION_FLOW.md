# Application Flow Documentation

## Complete Application Flow

This document explains the complete flow of data through the Weather Forecast application, from user input to displaying results.

---

## 🎯 High-Level Flow Overview

```
User Input (Address)
    ↓
Controller (Validates Input)
    ↓
ForecastService (Orchestrates)
    ↓
GeocodingService (Converts Address → Coordinates + Zip Code)
    ↓
Cache Check (By Zip Code)
    ├─→ Cache Hit → Return Cached Data
    └─→ Cache Miss → WeatherApiService → OpenWeatherMap API
    ↓
Cache Storage (30 min TTL)
    ↓
Response to User (Web View or JSON API)
```

---

## 📋 Detailed Flow Breakdown

### **Flow 1: Web Interface (HTML)**

#### Step 1: User Accesses Form
- **Route:** `GET /` or `GET /forecasts/new`
- **Controller:** `ForecastsController#new`
- **Action:** Creates empty `Forecast` object
- **View:** Renders `app/views/forecasts/new.html.erb`
- **Result:** User sees address input form

#### Step 2: User Submits Address
- **Route:** `POST /forecasts`
- **Controller:** `ForecastsController#create`
- **Action:**
  1. Receives address from form params
  2. Creates `Forecast` object with address
  3. Validates address (presence, minimum length)

**Code:**
```ruby
@forecast = Forecast.new(forecast_params)
if @forecast.valid?
  # Continue to Step 3
else
  # Render form with errors
end
```

#### Step 3: Call ForecastService
- **Service:** `ForecastService.fetch_forecast(address)`
- **Location:** `app/services/forecast_service.rb`

**ForecastService Flow:**

##### 3.1: Geocode Address
- **Service:** `GeocodingService.geocode(address)`
- **Location:** `app/services/geocoding_service.rb`
- **Process:**
  1. Uses Geocoder gem to search address
  2. Calls OpenStreetMap Nominatim API
  3. Extracts:
     - Latitude
     - Longitude
     - Zip Code (from postal_code or address_components)
- **Returns:**
  ```ruby
  {
    success: true,
    latitude: 37.4224764,
    longitude: -122.0842499,
    zip_code: "94043"
  }
  ```
- **On Error:** Returns `{ success: false, error: "..." }`

##### 3.2: Check Cache
- **Cache Key:** `"forecast:#{zip_code}"` (e.g., `"forecast:94043"`)
- **Action:** `Rails.cache.read(cache_key)`
- **Cache Store:** Memory store (development) or Redis (production)

**Cache Hit Path:**
```ruby
if cached_data
  return {
    success: true,
    data: cached_data.merge(cached: true),
    cached: true  # ← Indicates data from cache
  }
end
```

**Cache Miss Path:** Continue to Step 3.3

##### 3.3: Fetch Weather Data (If Cache Miss)
- **Service:** `WeatherApiService.fetch_weather(latitude, longitude)`
- **Location:** `app/services/weather_api_service.rb`
- **Process:**
  1. Builds API URL with coordinates and API key
  2. Makes HTTP GET request to OpenWeatherMap API
  3. Parses JSON response
  4. Extracts weather data:
     - Current temperature
     - High temperature
     - Low temperature
     - Description
     - Humidity
     - Wind speed
- **API Endpoint:** `https://api.openweathermap.org/data/2.5/weather`
- **Returns:**
  ```ruby
  {
    success: true,
    current_temp: 72.5,
    high_temp: 80.0,
    low_temp: 65.0,
    description: "Clear sky",
    humidity: 50,
    wind_speed: 10.5
  }
  ```

##### 3.4: Prepare Forecast Data
- **Action:** Combines all data into forecast hash
- **Code:**
  ```ruby
  forecast_data = {
    address: @address,
    zip_code: zip_code,
    current_temp: weather_result[:current_temp],
    high_temp: weather_result[:high_temp],
    low_temp: weather_result[:low_temp],
    description: weather_result[:description],
    humidity: weather_result[:humidity],
    wind_speed: weather_result[:wind_speed],
    cached: false
  }
  ```

##### 3.5: Store in Cache
- **Action:** `Rails.cache.write(cache_key, forecast_data, expires_in: 30.minutes)`
- **TTL:** 30 minutes
- **Key:** `"forecast:#{zip_code}"`

##### 3.6: Return to Controller
- **Returns:**
  ```ruby
  {
    success: true,
    data: forecast_data,
    cached: false  # or true if from cache
  }
  ```

#### Step 4: Controller Processes Response
- **Location:** `ForecastsController#create`

**Success Path:**
```ruby
if forecast_data[:success]
  @forecast.assign_attributes(forecast_data[:data])
  @forecast.cached = forecast_data[:cached]
  # Redirect to show page with data in URL params
  redirect_to forecast_path(...)
end
```

**Error Path:**
```ruby
else
  flash.now[:alert] = forecast_data[:error]
  render :new, status: :unprocessable_entity
end
```

#### Step 5: Display Results
- **Route:** `GET /forecasts/:id` (with params)
- **Controller:** `ForecastsController#show`
- **Action:** Creates `Forecast` object from URL parameters
- **View:** Renders `app/views/forecasts/show.html.erb`
- **Displays:**
  - Address
  - Current temperature
  - High/Low temperatures
  - Weather description
  - Humidity
  - Wind speed
  - **Cache indicator** (yellow if cached, green if fresh)

---

### **Flow 2: API Endpoint (JSON)**

#### Step 1: API Request
- **Route:** `GET /api/v1/forecast?address=...` or `POST /api/v1/forecast`
- **Controller:** `Api::V1::ForecastsController#show` or `#create`
- **Action:** Validates address parameter

#### Step 2: Call ForecastService
- **Same as Web Flow Step 3**
- Uses the same `ForecastService.fetch_forecast(address)`
- Same caching logic applies

#### Step 3: Return JSON Response

**Success Response:**
```json
{
  "success": true,
  "data": {
    "address": "1600 Amphitheatre Parkway, Mountain View, CA",
    "zip_code": "94043",
    "current_temperature": 72.5,
    "high_temperature": 80.0,
    "low_temperature": 65.0,
    "description": "Clear sky",
    "humidity": 50,
    "wind_speed": 10.5,
    "cached": false,
    "cache_ttl_minutes": 30
  },
  "cached": false,
  "timestamp": "2024-01-15T10:30:00Z"
}
```

**Error Response:**
```json
{
  "success": false,
  "error": "Address not found. Please check the address and try again.",
  "message": "Failed to fetch weather forecast"
}
```

---

## 🔄 Caching Flow (Detailed)

### First Request (Cache Miss)

```
1. User requests forecast for "New York, NY 10001"
   ↓
2. GeocodingService extracts zip_code: "10001"
   ↓
3. Cache check: Rails.cache.read("forecast:10001")
   → Returns: nil (cache miss)
   ↓
4. WeatherApiService fetches from OpenWeatherMap API
   ↓
5. Data stored in cache:
   Rails.cache.write("forecast:10001", data, expires_in: 30.minutes)
   ↓
6. Return data with cached: false
```

### Subsequent Request (Cache Hit)

```
1. User requests forecast for "New York, NY 10001" (within 30 min)
   ↓
2. GeocodingService extracts zip_code: "10001"
   ↓
3. Cache check: Rails.cache.read("forecast:10001")
   → Returns: cached data (cache hit)
   ↓
4. Skip API call (no external request)
   ↓
5. Return cached data with cached: true
```

### Cache Expiration

```
After 30 minutes:
- Cache entry expires
- Next request triggers fresh API call
- New data cached for another 30 minutes
```

---

## 🎨 Visual Flow Diagram

```
┌─────────────────────────────────────────────────────────────┐
│                    USER INPUT                               │
│         (Address: "New York, NY 10001")                     │
└──────────────────────┬──────────────────────────────────────┘
                       │
                       ▼
┌─────────────────────────────────────────────────────────────┐
│              ForecastsController#create                      │
│  • Validates address                                         │
│  • Calls ForecastService.fetch_forecast(address)            │
└──────────────────────┬──────────────────────────────────────┘
                       │
                       ▼
┌─────────────────────────────────────────────────────────────┐
│              ForecastService.fetch_forecast                   │
│                                                               │
│  Step 1: GeocodingService.geocode(address)                   │
│    └─→ OpenStreetMap Nominatim API                           │
│    └─→ Returns: { lat, lon, zip_code }                      │
│                                                               │
│  Step 2: Check Cache                                        │
│    Key: "forecast:#{zip_code}"                              │
│    ┌─────────────────────────────────────┐                  │
│    │ Cache Hit?                          │                  │
│    ├─ YES → Return cached data            │                  │
│    └─ NO  → Continue to Step 3            │                  │
│    └─────────────────────────────────────┘                  │
│                                                               │
│  Step 3: WeatherApiService.fetch_weather(lat, lon)           │
│    └─→ OpenWeatherMap API                                    │
│    └─→ Returns: { temp, high, low, desc, etc }              │
│                                                               │
│  Step 4: Prepare forecast_data hash                         │
│                                                               │
│  Step 5: Cache the data (30 min TTL)                        │
│    Rails.cache.write(key, data, expires_in: 30.minutes)    │
│                                                               │
│  Step 6: Return { success: true, data: ..., cached: false } │
└──────────────────────┬──────────────────────────────────────┘
                       │
                       ▼
┌─────────────────────────────────────────────────────────────┐
│              Controller Processes Response                    │
│  • If success: Redirect to show page with data               │
│  • If error: Render form with error message                  │
└──────────────────────┬──────────────────────────────────────┘
                       │
                       ▼
┌─────────────────────────────────────────────────────────────┐
│              ForecastsController#show                        │
│  • Creates Forecast object from params                       │
│  • Renders view with forecast data                          │
└──────────────────────┬──────────────────────────────────────┘
                       │
                       ▼
┌─────────────────────────────────────────────────────────────┐
│                    USER SEES RESULT                          │
│  • Weather forecast details                                  │
│  • Cache indicator (cached/fresh)                           │
└─────────────────────────────────────────────────────────────┘
```

---

## 🔍 Error Handling Flow

### Error Scenario 1: Invalid Address
```
User Input: "InvalidAddress12345"
    ↓
GeocodingService.geocode()
    ↓
Geocoder.search() returns empty results
    ↓
Return: { success: false, error: "Address not found..." }
    ↓
Controller: Render form with error message
```

### Error Scenario 2: API Failure
```
Geocoding succeeds
    ↓
Cache miss
    ↓
WeatherApiService.fetch_weather()
    ↓
OpenWeatherMap API returns error (401, 404, 429, etc.)
    ↓
Return: { success: false, error: "API error..." }
    ↓
Controller: Render form with error message
```

### Error Scenario 3: Network Error
```
WeatherApiService.fetch_weather()
    ↓
HTTParty.get() raises HTTParty::Error
    ↓
Rescue block catches error
    ↓
Return: { success: false, error: "Network error..." }
    ↓
Controller: Render form with error message
```

---

## 📊 Data Flow Summary

| Step | Component | Input | Output | Storage |
|------|-----------|-------|--------|---------|
| 1 | Controller | Address string | Validated address | - |
| 2 | GeocodingService | Address | { lat, lon, zip_code } | - |
| 3 | Cache Check | Zip code | Cached data or nil | Memory/Redis |
| 4 | WeatherApiService | Coordinates | Weather data | - |
| 5 | ForecastService | All data | Forecast hash | - |
| 6 | Cache Write | Forecast data | - | Memory/Redis (30 min) |
| 7 | Controller | Forecast data | View/JSON response | - |

---

## 🔑 Key Points

1. **Single Source of Truth:** `ForecastService` orchestrates the entire flow
2. **Caching Strategy:** Cache-aside pattern with 30-minute TTL
3. **Cache Key:** Based on zip code, not full address
4. **Error Handling:** Each service returns `{ success: true/false, ... }`
5. **No Database:** Forecast data is NOT stored in database, only in cache
6. **Service Objects:** Business logic separated from controllers
7. **Reusability:** Same service used for both web and API endpoints

---

## 🚀 Performance Optimizations

1. **Cache First:** Always check cache before API call
2. **Zip Code Key:** Efficient cache key (not full address)
3. **30-Minute TTL:** Balances freshness with API rate limits
4. **Service Reuse:** Same service for web and API
5. **Error Short-Circuit:** Fail fast on geocoding errors (no API call)

---

This flow ensures efficient, cached, and error-resilient weather forecast retrieval!


