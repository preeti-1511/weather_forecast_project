# Architecture Documentation

## Overview

This Weather Forecast application follows a **Service-Oriented Architecture** with clear separation of concerns. The application is built using Ruby on Rails 7.0 and implements several design patterns and best practices.

## Design Patterns

### 1. Service Object Pattern

The application uses **Service Objects** to encapsulate business logic outside of controllers and models. This pattern provides:

- **Single Responsibility**: Each service has one clear purpose
- **Testability**: Services can be tested in isolation
- **Reusability**: Services can be used across different parts of the application
- **Maintainability**: Changes to business logic are isolated

**Services:**
- `ForecastService`: Orchestrates the forecast retrieval workflow
- `GeocodingService`: Handles address geocoding
- `WeatherApiService`: Manages external API communication

### 2. Value Object Pattern

The `Forecast` model acts as a **Value Object** (using ActiveModel) rather than a persisted ActiveRecord model. This is appropriate because:

- Forecast data is transient and doesn't need persistence
- Data comes from external APIs
- Caching is handled at the service layer, not the model layer

### 3. Strategy Pattern (Caching)

The caching strategy is implemented using Rails' built-in cache store with a configurable TTL. The strategy:

- Checks cache first (cache-aside pattern)
- Uses zip code as cache key for efficient lookups
- Implements 30-minute TTL as specified
- Provides cache indicators to users

## Application Structure

```
app/
├── controllers/
│   ├── application_controller.rb    # Base controller
│   └── forecasts_controller.rb      # Handles forecast requests
├── models/
│   └── forecast.rb                  # Value object for forecast data
├── services/
│   ├── forecast_service.rb          # Main orchestration service
│   ├── geocoding_service.rb         # Address geocoding
│   └── weather_api_service.rb       # Weather API integration
└── views/
    ├── layouts/
    │   └── application.html.erb     # Main layout
    └── forecasts/
        ├── new.html.erb             # Address input form
        └── show.html.erb            # Forecast display
```

## Data Flow

1. **User Input**: User enters address in the form
2. **Controller**: `ForecastsController#create` receives the address
3. **Validation**: Forecast model validates the address
4. **Service Orchestration**: `ForecastService.fetch_forecast` is called
5. **Geocoding**: `GeocodingService` converts address to coordinates and zip code
6. **Cache Check**: Service checks cache using zip code as key
7. **API Call** (if cache miss): `WeatherApiService` fetches fresh data
8. **Cache Storage**: Fresh data is stored in cache with 30-minute TTL
9. **Response**: Forecast data is returned to controller
10. **View Rendering**: Controller renders the forecast view

## Caching Strategy

### Cache Key Format
```
forecast:{zip_code}
```

### Cache TTL
- **30 minutes** as specified in requirements
- Configurable via `ForecastService::CACHE_TTL` constant

### Cache Store
- **Development**: Memory store (configurable)
- **Production**: Should use Redis or Memcached for distributed caching

### Cache Indicators
- **Yellow badge**: Data served from cache
- **Green badge**: Fresh data from API

## Error Handling

### Geocoding Errors
- Invalid addresses → User-friendly error message
- Network errors → Graceful error handling with retry capability
- Missing zip codes → Clear error message

### API Errors
- **401**: Invalid API key → Configuration error message
- **404**: Location not found → User-friendly message
- **429**: Rate limit exceeded → Retry suggestion
- **Network errors**: Graceful degradation

### User Experience
- Errors are displayed in flash messages
- Form is re-rendered with error state
- No application crashes on external service failures

## Testing Strategy

### Unit Tests
- **Models**: Test validations and attribute handling
- **Services**: Test business logic with mocked dependencies
- **Controllers**: Test request/response handling

### Integration Tests
- End-to-end workflow testing
- Cache behavior verification
- Error handling scenarios

### Test Coverage
- All services have comprehensive test coverage
- Controllers are tested for all actions
- Models are tested for validations

## Scalability Considerations

### Current Limitations
1. **In-memory cache**: Not suitable for multi-server deployments
2. **Synchronous API calls**: Blocks request thread
3. **No rate limiting**: Could hit API limits under load
4. **SQLite database**: Not suitable for production

### Production Recommendations

1. **Caching**
   - Use Redis for distributed caching
   - Implement cache warming for popular locations
   - Add cache compression

2. **API Management**
   - Implement request queuing
   - Add retry logic with exponential backoff
   - Use circuit breakers for API failures
   - Consider multiple API providers

3. **Background Jobs**
   - Move API calls to background jobs (Sidekiq)
   - Implement job queues
   - Add job retry mechanisms

4. **Database**
   - Migrate to PostgreSQL
   - Add proper indexes
   - Implement connection pooling

5. **Monitoring**
   - Add application monitoring (New Relic, Datadog)
   - Track cache hit/miss rates
   - Monitor API response times
   - Set up alerting

## Security Considerations

1. **API Keys**: Stored in environment variables, never committed
2. **Input Validation**: Addresses are validated before processing
3. **Error Messages**: Don't expose sensitive information
4. **Rate Limiting**: Should be implemented in production

## Code Quality

### Naming Conventions
- **Classes**: PascalCase (`ForecastService`)
- **Methods**: snake_case (`fetch_forecast`)
- **Variables**: snake_case (`zip_code`)
- **Constants**: SCREAMING_SNAKE_CASE (`CACHE_TTL`)

### Encapsulation
- Services have clear public interfaces
- Private methods for internal logic
- No god objects or methods doing too much

### Documentation
- Comprehensive inline comments
- README with setup instructions
- Architecture documentation
- Test coverage documentation

## Dependencies

### Core Gems
- **rails**: Web framework
- **httparty**: HTTP client for API calls
- **geocoder**: Address geocoding
- **dotenv-rails**: Environment variable management

### Testing Gems
- **rspec-rails**: Testing framework
- **webmock**: HTTP request stubbing
- **factory_bot_rails**: Test data factories

## Future Enhancements

1. **Extended Forecast**: Add 5-day or 7-day forecast
2. **Historical Data**: Store and display historical forecasts
3. **User Preferences**: Save favorite locations
4. **Email Alerts**: Weather alerts via email
5. **Mobile API**: RESTful API for mobile apps
6. **Graphs/Charts**: Visual representation of weather data










