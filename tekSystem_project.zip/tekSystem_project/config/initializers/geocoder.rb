# Geocoder configuration
# Configure geocoding service settings
Geocoder.configure(
  # Geocoding service
  lookup: :nominatim, # Using OpenStreetMap Nominatim (free, no API key required)
  
  # IP address geocoding service
  ip_lookup: :ipapi_com,
  
  # Language
  language: :en,
  
  # Use HTTPS
  use_https: true,
  
  # HTTP proxy
  http_proxy: nil,
  
  # HTTPS proxy
  https_proxy: nil,
  
  # Timeout
  timeout: 5,
  
  # Units
  units: :mi
)










