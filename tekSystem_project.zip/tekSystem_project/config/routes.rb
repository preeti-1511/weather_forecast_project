Rails.application.routes.draw do
  # Define your application routes per the DSL in https://guides.rubyonrails.org/routing.html

  # Reveal health status on /up that returns 200 if the app boots with no exceptions, otherwise 500.
  # Can be used by load balancers and uptime monitors to verify that the app is live.
  get "up" => "rails/health#show", as: :rails_health_check

  # Web routes (HTML views)
  root 'forecasts#new'
  resources :forecasts, only: [:new, :create]
  get 'forecasts/results', to: 'forecasts#show', as: :forecast_result

  # API routes (JSON responses)
  namespace :api do
    namespace :v1 do
      # GET /api/v1/forecast?address=...
      # POST /api/v1/forecast with JSON body
      get 'forecast', to: 'forecasts#show'
      post 'forecast', to: 'forecasts#create'
      
      # Health check endpoint
      get 'forecast/health', to: 'forecasts#health'
    end
  end
end







